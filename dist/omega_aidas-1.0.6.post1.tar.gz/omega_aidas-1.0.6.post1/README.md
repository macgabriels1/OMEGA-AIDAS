# Omega AIDAS

`omega_aidas` is a Python package that provides the OMEGA-AIDAS fully automated system that compiles, implements, and then deploys your program code—end to end.

## Installation

```bash
pip install omega-aidas==1.0.3